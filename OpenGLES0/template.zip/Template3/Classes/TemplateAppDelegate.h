//
//  TemplateAppDelegate.h
//  Template
//
//  Created by hanbit on 11. 5. 2..
//  Copyright 2011 SEOUL. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TemplateViewController;

@interface TemplateAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TemplateViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TemplateViewController *viewController;

@end

