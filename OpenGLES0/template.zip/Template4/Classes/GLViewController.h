//
//  GLViewController.h
//  Template
//
//  Created by hanbit on 11. 5. 2..
//  Copyright SEOUL 2011. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GLView.h"

@interface GLViewController : UIViewController <GLViewDelegate>
{
}
@end
