//
//  TemplateAppDelegate.m
//  Template
//
//  Created by hanbit on 11. 5. 2..
//  Copyright SEOUL 2011. All rights reserved.
//

#import "TemplateAppDelegate.h"
#import "GLView.h"
#import "ConstantsAndMacros.h"

@implementation TemplateAppDelegate

@synthesize window;
@synthesize glView;

- (void)applicationDidFinishLaunching:(UIApplication *)application {
    
	glView.animationInterval = 1.0 / kRenderingFrequency;
	[glView startAnimation];
}


- (void)applicationWillResignActive:(UIApplication *)application {
	glView.animationInterval = 1.0 / kInactiveRenderingFrequency;
}


- (void)applicationDidBecomeActive:(UIApplication *)application {
	glView.animationInterval = 1.0 / 60.0;
}


- (void)dealloc {
	[window release];
	[glView release];
	[super dealloc];
}

@end
