//
//  TemplateAppDelegate.h
//  Template
//
//  Created by hanbit on 11. 5. 2..
//  Copyright SEOUL 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@class GLView;

@interface TemplateAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    GLView *glView;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet GLView *glView;

@end

