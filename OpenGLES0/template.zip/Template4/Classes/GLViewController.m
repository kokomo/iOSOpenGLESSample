//
//  GLViewController.m
//  Template
//
//  Created by hanbit on 11. 5. 2..
//  Copyright SEOUL 2011. All rights reserved.
//

#import "GLViewController.h"
#import "ConstantsAndMacros.h"
#import "OpenGLCommon.h"

@implementation GLViewController

- (void)drawView:(UIView *)theView
{
	glClearColor(1.0, 0.0, 0.0, 1.0);
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    // Drawing code here
	
	NSLog(@"drawView 호출");
    
}

- (void)dealloc 
{
    [super dealloc];
}
@end
